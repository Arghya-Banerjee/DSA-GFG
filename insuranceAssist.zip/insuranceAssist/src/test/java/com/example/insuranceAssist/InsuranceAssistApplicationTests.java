package com.example.insuranceAssist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceAssistApplicationTests {

	@Test
	void contextLoads() {
	}

}
