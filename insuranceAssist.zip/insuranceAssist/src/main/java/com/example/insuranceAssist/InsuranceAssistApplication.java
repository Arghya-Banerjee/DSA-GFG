package com.example.insuranceAssist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuranceAssistApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceAssistApplication.class, args);
	}

}
